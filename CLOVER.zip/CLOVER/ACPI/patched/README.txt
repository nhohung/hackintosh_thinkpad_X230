You must delete SSDT.aml if you are not using Core i7-3520M CPU.
You have to substitute the SSDT.aml with the one SSDT.aml that suits your CPU.